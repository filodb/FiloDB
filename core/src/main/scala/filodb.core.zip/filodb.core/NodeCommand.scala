package filodb.core

// Public, external Actor/Akka API for NodeCoordinatorActor, so every incoming command should be a NodeCommand
trait NodeCommand
trait NodeResponse

